﻿function displayWindow(url,width,height) {
	window.open(url,"displayWindow",'width=' + width + ',height=' + height + ',screenX=0,screenY=0,top=0,left=0,resizable,scrollbars,location=0,status=1');
}